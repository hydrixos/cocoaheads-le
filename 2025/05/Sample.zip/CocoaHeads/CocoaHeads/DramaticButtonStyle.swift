import SwiftUI

struct DramaticButtonStyle: ButtonStyle {
    var colors: [Color] = [.red, .orange]
    var foregroundColor: Color = .white
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(.headline, design: .serif).weight(.heavy))
            .foregroundColor(foregroundColor)
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(
                LinearGradient(
                    gradient: Gradient(colors: colors),
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .clipShape(Capsule())
            .shadow(color: .black.opacity(0.3), radius: 5, x: 0, y: 2)
            .scaleEffect(configuration.isPressed ? 0.94 : 1)
            .brightness(configuration.isPressed ? 0.1 : 0)
            .animation(.spring(), value: configuration.isPressed)
    }
}

// Button style with coffee colors (brown tones)
struct CoffeeButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        DramaticButtonStyle(
            colors: [Color(red: 0.6, green: 0.4, blue: 0.2), Color(red: 0.8, green: 0.6, blue: 0.4)],
            foregroundColor: .white
        ).makeBody(configuration: configuration)
    }
}

// Button style with blue tones for secondary actions
struct WaterButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        DramaticButtonStyle(
            colors: [Color.blue, Color.blue.opacity(0.7)],
            foregroundColor: .white
        ).makeBody(configuration: configuration)
    }
}

// Extension to apply the button styles more easily
extension View {
    func dramaticButtonStyle() -> some View {
        self.buttonStyle(DramaticButtonStyle())
    }
    
    func coffeeButtonStyle() -> some View {
        self.buttonStyle(CoffeeButtonStyle())
    }
    
    func waterButtonStyle() -> some View {
        self.buttonStyle(WaterButtonStyle())
    }
} 