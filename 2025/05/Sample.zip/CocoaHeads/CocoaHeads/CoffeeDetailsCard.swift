//
//  CoffeeDetailsCard.swift
//  CocoaHeads
//
//  Created by Max Seelemann on 15.05.25.
//

import SwiftUI

struct CoffeeDetailsCard: View {
    let coffeeName: String
    let location: String
    let dateConsumed: Date
    let coffeeRating: Int
    let placeRating: Int
    let colorScheme: ColorScheme
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Title and Location
            VStack(alignment: .leading, spacing: 8) {
                Text(coffeeName)
                    .font(AppFonts.title)
                
                HStack {
                    Label(location, systemImage: "mappin.circle.fill")
                        .font(AppFonts.caption)
                        .foregroundColor(.secondary)
                    Spacer()
                    Text(dateConsumed, style: .date)
                        .font(AppFonts.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Divider()
            
            // Ratings Section
            HStack(spacing: 40) {
                StarRatingView(title: "Coffee", rating: coffeeRating)
                StarRatingView(title: "Place", rating: placeRating)
            }
            .padding(.vertical, 4)
        }
        .padding(20)
        .background(colorScheme == .dark ? Color(.systemGray6) : Color.white.opacity(0.97))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        .padding(.horizontal)
    }
}

#Preview {
    CoffeeDetailsCard(
        coffeeName: "Ethiopian Blend",
        location: "Awesome Coffee Shop",
        dateConsumed: Date(),
        coffeeRating: 5,
        placeRating: 4,
        colorScheme: .light
    )
} 