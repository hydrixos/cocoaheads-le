//
//  Fonts.swift
//  CocoaHeads
//
//  Created by Max Seelemann on 15.05.25.
//

import SwiftUI

struct AppFonts {
    static let title = Font.system(.largeTitle, design: .serif).weight(.bold)
    static let headline = Font.system(.headline, design: .serif)
    static let body = Font.system(.body, design: .serif)
    static let caption = Font.system(.subheadline, design: .serif)
} 