//
//  LocationPickerView.swift
//  CocoaHeads
//
//  Created by Max Seelemann on 15.05.25.
//

import SwiftUI
import MapKit
import CoreLocation

struct LocationPickerView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var searchText: String = ""
    @State private var searchResults: [MKLocalSearchCompletion] = []
    @StateObject private var completerDelegate = LocationCompleterDelegate()
    @State private var region: MKCoordinateRegion
    @State private var selectedName: String
    @State private var selectedCoordinate: CLLocationCoordinate2D
    @State private var isSearching = false
    @State private var isReverseGeocoding = false
    @State private var completer = MKLocalSearchCompleter()
    
    let onSelect: (String, CLLocationCoordinate2D) -> Void
    
    init(initialName: String, initialCoordinate: CLLocationCoordinate2D, onSelect: @escaping (String, CLLocationCoordinate2D) -> Void) {
        _region = State(initialValue: MKCoordinateRegion(center: initialCoordinate, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)))
        _selectedName = State(initialValue: initialName)
        _selectedCoordinate = State(initialValue: initialCoordinate)
        self.onSelect = onSelect
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack {
                    TextField("Search for coffee places", text: $searchText)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(8)
                        .onChange(of: searchText) { newValue in
                            completer.queryFragment = newValue
                        }
                }
                
                if !searchResults.isEmpty {
                    List(searchResults, id: \.self) { completion in
                        Button(action: {
                            selectCompletion(completion)
                        }) {
                            VStack(alignment: .leading) {
                                Text(completion.title)
                                if !completion.subtitle.isEmpty {
                                    Text(completion.subtitle)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                    }
                    .frame(maxHeight: 200)
                }
                
                if isSearching {
                    ProgressView("Loading location...")
                        .padding()
                }
                
                Map(coordinateRegion: $region, annotationItems: [MapPin(coordinate: selectedCoordinate)]) { pin in
                    MapMarker(coordinate: pin.coordinate)
                }
                .gesture(
                    TapGesture()
                        .onEnded { value in
                            // Convert tap location to map coordinate
                            // Use a DragGesture to get the precise location
                        }
                )
                .simultaneousGesture(
                    DragGesture(minimumDistance: 0)
                        .onEnded { value in
                            let mapView = MKMapView(frame: CGRect(origin: .zero, size: CGSize(width: 1, height: 1)))
                            let location = value.location
                            let coordinate = mapView.convert(location, toCoordinateFrom: nil)
                            updateLocation(to: coordinate)
                        }
                )
                .frame(height: 300)
                .cornerRadius(12)
                .padding()
                
                if isReverseGeocoding {
                    ProgressView("Finding place name...")
                        .padding()
                }
                
                Text(selectedName)
                    .font(.headline)
                    .padding(.bottom)
                
                Button("Select This Location") {
                    onSelect(selectedName, selectedCoordinate)
                    dismiss()
                }
                .coffeeButtonStyle()
                .padding(.bottom)
                .disabled(isSearching)
            }
            .navigationTitle("Pick Location")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                        .waterButtonStyle()
                }
            }
            .onAppear {
                completer.resultTypes = .pointOfInterest
                completer.pointOfInterestFilter = MKPointOfInterestFilter(including: [.cafe])
                completer.delegate = completerDelegate
                completerDelegate.onUpdate = { results in
                    self.searchResults = results
                }
            }
        }
    }
    
    private func selectCompletion(_ completion: MKLocalSearchCompletion) {
        isSearching = true
        let searchRequest = MKLocalSearch.Request(completion: completion)
        searchRequest.pointOfInterestFilter = MKPointOfInterestFilter(including: [.cafe])
        let search = MKLocalSearch(request: searchRequest)
        search.start { response, error in
            defer { isSearching = false }
            guard let item = response?.mapItems.first else { return }
            selectedName = item.name ?? completion.title
            selectedCoordinate = item.placemark.coordinate
            region.center = item.placemark.coordinate
            searchText = ""
            searchResults = []
        }
    }
    
    private func updateLocation(to coordinate: CLLocationCoordinate2D) {
        selectedCoordinate = coordinate
        region.center = coordinate
        isReverseGeocoding = true
        let location = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
        CLGeocoder().reverseGeocodeLocation(location) { placemarks, error in
            isReverseGeocoding = false
            if let placemark = placemarks?.first {
                selectedName = [placemark.name, placemark.locality, placemark.country].compactMap { $0 }.joined(separator: ", ")
            } else {
                let latString = String(format: "%.4f", coordinate.latitude)
                let lonString = String(format: "%.4f", coordinate.longitude)
                selectedName = String(localized: "Lat: \(latString), Lon: \(lonString)")
            }
        }
    }
}

private class LocationCompleterDelegate: NSObject, MKLocalSearchCompleterDelegate, ObservableObject {
    var onUpdate: (([MKLocalSearchCompletion]) -> Void)?
    func completerDidUpdateResults(_ completer: MKLocalSearchCompleter) {
        onUpdate?(completer.results)
    }
    func completer(_ completer: MKLocalSearchCompleter, didFailWithError error: Error) {
        onUpdate?([])
    }
}

struct MapPin: Identifiable {
    let id = UUID()
    let coordinate: CLLocationCoordinate2D
} 