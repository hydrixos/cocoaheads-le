//
//  CoffeeNotesSection.swift
//  CocoaHeads
//
//  Created by Max Seelemann on 15.05.25.
//

import SwiftUI

struct CoffeeNotesSection: View {
    let notes: String
    let colorScheme: ColorScheme
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Notes", systemImage: "note.text")
                .font(AppFonts.headline)
            
            Text(notes)
                .font(AppFonts.body)
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(colorScheme == .dark ? Color(.systemGray5) : Color(.systemGray6))
                .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .padding(20)
        .background(colorScheme == .dark ? Color(.systemGray6) : Color.white.opacity(0.97))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        .padding(.horizontal)
    }
}

#Preview {
    CoffeeNotesSection(
        notes: "Great place with excellent ambiance. The coffee had a subtle fruity note with chocolatey finish.",
        colorScheme: .light
    )
} 