//
//  CocoaHeadsApp.swift
//  CocoaHeads
//
//  Created by Max Seelemann on 15.05.25.
//

import SwiftUI
import SwiftData
import WidgetKit

// A simple struct to represent coffee data for display in the widget
struct CoffeeDataDisplay: Codable {
    let coffeeName: String
    let location: String
    let dateConsumed: Date
    let coffeeRating: Int
    let placeRating: Int
}

@main
struct CoffeeJournalApp: App {
    @State private var showLaunchScreen = true
    @Environment(\.modelContext) private var modelContext
    
    var sharedModelContainer: ModelContainer = {
        let schema = Schema([
            CoffeeEntry.self,
        ])
        
        // Use a shared app group container for the widget to access
        let modelConfiguration = ModelConfiguration(
            schema: schema,
            isStoredInMemoryOnly: false,
            groupContainer: .identifier("group.com.cocoaheads.journal")
        )

        do {
            return try ModelContainer(for: schema, configurations: [modelConfiguration])
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
    }()

    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView()
                    .onChange(of: modelContext.hasChanges) { _, hasChanges in
                        if hasChanges {
                            // Reload widget timelines when data changes
                            WidgetCenter.shared.reloadAllTimelines()
                        }
                    }
                
                if showLaunchScreen {
                    LaunchScreen()
                        .transition(.opacity)
                }
            }
            .onAppear {
                // Dismiss the launch screen after a delay
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    withAnimation(.easeOut(duration: 0.5)) {
                        showLaunchScreen = false
                    }
                }
            }
        }
        .modelContainer(sharedModelContainer)
    }
}

// App state object to manage app-wide state
class AppState: ObservableObject {
    @Published var showLaunchScreen = true
    
    init() {
        // Setup app appearance
        setupAppearance()
    }
    
    private func setupAppearance() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        
        // Apply appearance to all navigation bars
        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().compactAppearance = appearance
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
    }
}
