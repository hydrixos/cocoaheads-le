//
//  ContentView.swift
//  CocoaHeads
//
//  Created by Max Seelemann on 15.05.25.
//

import SwiftUI
import SwiftData

// Button style extensions
extension Button {
    func coffeeStyle() -> some View {
        self.padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.accentColor)
            )
            .foregroundColor(.white)
    }
    
    func waterStyle() -> some View {
        self.padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.accentColor, lineWidth: 1.5)
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.accentColor.opacity(0.1))
                    )
            )
            .foregroundColor(.accentColor)
    }
}

struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \CoffeeEntry.dateConsumed, order: .reverse) private var entries: [CoffeeEntry]
    
    @State private var showingAddEntry = false
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(entries) { entry in
                    NavigationLink {
                        CoffeeEntryDetail(entry: entry)
                    } label: {
                        CoffeeEntryRow(entry: entry)
                    }
                }
                .onDelete(perform: deleteEntries)
            }
            .navigationTitle("Coffee Journal")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton()
//                        .waterStyle()
                }
                ToolbarItem {
                    Button(action: { showingAddEntry = true }) {
                        Label("Add Coffee", systemImage: "plus")
                    }
                    .coffeeStyle()
                }
            }
            .sheet(isPresented: $showingAddEntry) {
                CoffeeEntryForm()
            }
            .overlay {
                if entries.isEmpty {
                    ContentUnavailableView(
                        "No Coffee Entries",
                        systemImage: "cup.and.saucer",
                        description: Text("Add your first coffee experience by tapping the + button.")
                    )
                }
            }
        }
    }
    
    private func deleteEntries(offsets: IndexSet) {
        withAnimation {
            for index in offsets {
                modelContext.delete(entries[index])
            }
        }
    }
}

struct CoffeeEntryRow: View {
    let entry: CoffeeEntry
    
    var body: some View {
        HStack {
            if let photoData = entry.photoData, let uiImage = UIImage(data: photoData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 60, height: 60)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            } else {
                ZStack {
                    Color.brown.opacity(0.15)
                    Image(systemName: "cup.and.saucer.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.brown)
                }
                .frame(width: 60, height: 60)
                .clipShape(RoundedRectangle(cornerRadius: 8))
            }
            
            VStack(alignment: .leading) {
                Text(entry.coffeeName)
                    .font(.headline)
                
                HStack {
                    Text(entry.location)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Spacer()
                    
                    Text(entry.dateConsumed, style: .date)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                HStack {
                    ForEach(1...5, id: \.self) { i in
                        Image(systemName: i <= entry.coffeeRating ? "star.fill" : "star")
                            .font(.caption)
                            .foregroundColor(i <= entry.coffeeRating ? .yellow : .gray)
                    }
                }
            }
        }
        .padding(.vertical, 4)
    }
}

#Preview {
    ContentView()
        .modelContainer(for: CoffeeEntry.self, inMemory: true)
}
