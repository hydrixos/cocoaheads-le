//
//  CoffeeEntry.swift
//  CocoaHeads
//
//  Created by Max Seelemann on 15.05.25.
//

import Foundation
import SwiftData
import CoreLocation

@Model
final class CoffeeEntry {
    var coffeeName: String
    var location: String
    var dateConsumed: Date
    var coffeeRating: Int
    var placeRating: Int
    var notes: String
    var photoData: Data?
    
    // Store coordinates as separate fields
    var latitude: Double?
    var longitude: Double?
    
    init(coffeeName: String, location: String, coordinates: CLLocationCoordinate2D? = nil, dateConsumed: Date = Date(), coffeeRating: Int = 0, placeRating: Int = 0, notes: String = "", photoData: Data? = nil) {
        self.coffeeName = coffeeName
        self.location = location
        self.dateConsumed = dateConsumed
        self.coffeeRating = coffeeRating
        self.placeRating = placeRating
        self.notes = notes
        self.photoData = photoData
        
        // Store the coordinates
        if let coordinates = coordinates {
            self.latitude = coordinates.latitude
            self.longitude = coordinates.longitude
        }
    }
    
    // Computed property to get and set coordinates
    @Transient
    var coordinates: CLLocationCoordinate2D? {
        get {
            guard let latitude = self.latitude, let longitude = self.longitude else {
                return nil
            }
            return CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        }
        set {
            self.latitude = newValue?.latitude
            self.longitude = newValue?.longitude
        }
    }
}
