//
//  StarRatingView.swift
//  CocoaHeads
//
//  Created by Max Seelemann on 15.05.25.
//

import SwiftUI

struct StarRatingView: View {
    let title: String
    let rating: Int
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(AppFonts.headline)
            
            HStack(spacing: 4) {
                ForEach(1...5, id: \.self) { i in
                    Image(systemName: i <= rating ? "star.fill" : "star")
                        .foregroundColor(i <= rating ? .yellow : .gray.opacity(0.3))
                        .imageScale(.medium)
                }
            }
        }
    }
}

#Preview {
    StarRatingView(title: "Coffee", rating: 4)
} 