//
//  CoffeeEntryForm.swift
//  CocoaHeads
//
//  Created by Max Seelemann on 15.05.25.
//

import SwiftUI
import CoreLocation
import PhotosUI
import MapKit

struct CoffeeEntryForm: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    
    var entryToEdit: CoffeeEntry?
    
    @State private var coffeeName: String = ""
    @State private var location: String = ""
    @State private var dateConsumed: Date = Date()
    @State private var coffeeRating: Int = 3
    @State private var placeRating: Int = 3
    @State private var notes: String = ""
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var photoData: Data?
    
    @StateObject private var locationManager = LocationManager()
    
    @State private var locationCoordinate: CLLocationCoordinate2D?
    @State private var showingLocationPicker = false
    
    init(entryToEdit: CoffeeEntry? = nil) {
        self.entryToEdit = entryToEdit
        // SwiftUI will set @State vars in .onAppear
    }
    
    var body: some View {
        NavigationStack {
            Form {
                Section("Coffee Details") {
                    TextField("Coffee Name", text: $coffeeName)
                    
                    HStack {
                        TextField("Location", text: $location)
                            .disabled(true)
                        Button(action: {
                            if let loc = locationManager.location?.coordinate {
                                locationCoordinate = loc
                            }
                            showingLocationPicker = true
                        }) {
                            Label("Select", systemImage: "mappin.and.ellipse")
                        }
                        .waterButtonStyle()
                    }
                    .onAppear {
                        locationManager.requestLocation()
                    }
                    .onChange(of: locationManager.placemark) {
                        if let placemark = locationManager.placemark, let name = placemark.name, location.isEmpty {
                            location = name
                        }
                        if let loc = locationManager.location?.coordinate, locationCoordinate == nil {
                            locationCoordinate = loc
                        }
                    }
                    
                    DatePicker("Date", selection: $dateConsumed, displayedComponents: [.date, .hourAndMinute])
                }
                
                Section("Ratings") {
                    VStack(alignment: .leading) {
                        Text("Coffee Rating")
                        HStack {
                            ForEach(1...5, id: \.self) { rating in
                                Image(systemName: rating <= coffeeRating ? "star.fill" : "star")
                                    .foregroundColor(rating <= coffeeRating ? .yellow : .gray)
                                    .onTapGesture {
                                        coffeeRating = rating
                                    }
                            }
                        }
                    }
                    
                    VStack(alignment: .leading) {
                        Text("Place Rating")
                        HStack {
                            ForEach(1...5, id: \.self) { rating in
                                Image(systemName: rating <= placeRating ? "star.fill" : "star")
                                    .foregroundColor(rating <= placeRating ? .yellow : .gray)
                                    .onTapGesture {
                                        placeRating = rating
                                    }
                            }
                        }
                    }
                }
                
                Section("Photo") {
                    VStack {
                        if let photoData = photoData, let uiImage = UIImage(data: photoData) {
                            Image(uiImage: uiImage)
                                .resizable()
                                .scaledToFit()
                                .frame(maxHeight: 300)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                        } else {
                            ZStack {
                                Color.brown.opacity(0.1)
                                VStack(spacing: 10) {
                                    Image(systemName: "camera.fill")
                                        .font(.system(size: 40))
                                        .foregroundColor(.brown)
                                    
                                    Text("Add a photo")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                            .frame(height: 200)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                        }
                        
                        PhotosPicker(selection: $selectedPhoto, matching: .images) {
                            Label("Choose Photo", systemImage: "photo")
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 8)
                                .foregroundColor(.white)
                        }
                        .coffeeButtonStyle()
                        .onChange(of: selectedPhoto) {
                            Task {
                                if let data = try? await selectedPhoto?.loadTransferable(type: Data.self) {
                                    photoData = data
                                }
                            }
                        }
                    }
                    .padding(.vertical, 8)
                }
                
                Section("Notes") {
                    TextEditor(text: $notes)
                        .frame(minHeight: 100)
                }
            }
            .navigationTitle(entryToEdit == nil ? "New Coffee Entry" : "Edit Coffee Entry")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                    .waterButtonStyle()
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        saveEntry()
                    }
                    .disabled(coffeeName.isEmpty)
                    .coffeeButtonStyle()
                }
            }
            .sheet(isPresented: $showingLocationPicker) {
                LocationPickerView(
                    initialName: location.isEmpty ? "Current Location" : location,
                    initialCoordinate: locationCoordinate ?? locationManager.location?.coordinate ?? CLLocationCoordinate2D(latitude: 0, longitude: 0)
                ) { name, coordinate in
                    location = name
                    locationCoordinate = coordinate
                }
            }
            .onAppear {
                if let entry = entryToEdit {
                    coffeeName = entry.coffeeName
                    location = entry.location
                    dateConsumed = entry.dateConsumed
                    coffeeRating = entry.coffeeRating
                    placeRating = entry.placeRating
                    notes = entry.notes
                    photoData = entry.photoData
                    locationCoordinate = entry.coordinates
                }
            }
        }
    }
    
    private func saveEntry() {
        if let entry = entryToEdit {
            entry.coffeeName = coffeeName
            entry.location = location
            entry.dateConsumed = dateConsumed
            entry.coffeeRating = coffeeRating
            entry.placeRating = placeRating
            entry.notes = notes
            entry.photoData = photoData
            entry.coordinates = locationCoordinate
        } else {
            let entry = CoffeeEntry(
                coffeeName: coffeeName,
                location: location,
                coordinates: locationCoordinate,
                dateConsumed: dateConsumed,
                coffeeRating: coffeeRating,
                placeRating: placeRating,
                notes: notes,
                photoData: photoData
            )
            modelContext.insert(entry)
        }
        dismiss()
    }
}

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private let locationManager = CLLocationManager()
    @Published var location: CLLocation?
    @Published var placemark: CLPlacemark?
    
    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }
    
    func requestLocation() {
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        self.location = location
        
        // Reverse geocode to get the location name
        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(location) { (placemarks, error) in
            if let error = error {
                print("Geocoding error: \(error.localizedDescription)")
                return
            }
            
            self.placemark = placemarks?.first
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location error: \(error.localizedDescription)")
    }
}

#Preview {
    CoffeeEntryForm()
        .modelContainer(for: CoffeeEntry.self, inMemory: true)
} 