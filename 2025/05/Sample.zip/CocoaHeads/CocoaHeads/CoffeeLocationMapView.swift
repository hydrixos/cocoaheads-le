//
//  CoffeeLocationMapView.swift
//  CocoaHeads
//
//  Created by Max Seelemann on 15.05.25.
//

import SwiftUI
import MapKit

struct CoffeeLocationMapView: View {
    let location: String
    let coordinate: CLLocationCoordinate2D
    @Binding var mapPosition: MapCameraPosition
    let colorScheme: ColorScheme
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Location", systemImage: "map")
                .font(AppFonts.headline)
            
            Map(position: $mapPosition) {
                Marker(location, coordinate: coordinate)
                    .tint(.brown)
            }
            .frame(height: 240)
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
            )
        }
        .padding(20)
        .background(colorScheme == .dark ? Color(.systemGray6) : Color.white.opacity(0.97))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        .padding(.horizontal)
    }
}

#Preview {
    CoffeeLocationMapView(
        location: "Awesome Coffee Shop",
        coordinate: CLLocationCoordinate2D(latitude: 48.137154, longitude: 11.576124),
        mapPosition: .constant(.automatic),
        colorScheme: .light
    )
} 