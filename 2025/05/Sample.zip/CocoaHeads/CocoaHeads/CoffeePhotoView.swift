//
//  CoffeePhotoView.swift
//  CocoaHeads
//
//  Created by Max Seelemann on 15.05.25.
//

import SwiftUI

struct CoffeePhotoView: View {
    let photoData: Data?
    
    var body: some View {
        if let photoData = photoData, let uiImage = UIImage(data: photoData) {
            Image(uiImage: uiImage)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(maxWidth: .infinity)
                .frame(height: 280)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(radius: 5)
                .padding(.horizontal)
        } else {
            ZStack {
                LinearGradient(
                    colors: [.brown.opacity(0.7), .brown.opacity(0.2)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                VStack(spacing: 12) {
                    Image(systemName: "cup.and.saucer.fill")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100, height: 100)
                        .foregroundColor(.white)
                        .shadow(radius: 2)
                    
                    Text("No Photo")
                        .font(AppFonts.caption)
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 280)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(radius: 4)
            .padding(.horizontal)
        }
    }
}

#Preview {
    CoffeePhotoView(photoData: nil)
} 