//
//  CoffeeEntryDetail.swift
//  CocoaHeads
//
//  Created by Max Seelemann on 15.05.25.
//

import SwiftUI
import MapKit

struct CoffeeEntryDetail: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.colorScheme) private var colorScheme
    @State private var showingEdit = false
    @State private var mapPosition: MapCameraPosition = .automatic
    let entry: CoffeeEntry
    
    
    
    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                CoffeePhotoView(photoData: entry.photoData)
                
                CoffeeDetailsCard(
                    coffeeName: entry.coffeeName,
                    location: entry.location,
                    dateConsumed: entry.dateConsumed,
                    coffeeRating: entry.coffeeRating,
                    placeRating: entry.placeRating,
                    colorScheme: colorScheme
                )
                
                if !entry.notes.isEmpty {
                    CoffeeNotesSection(notes: entry.notes, colorScheme: colorScheme)
                }
                
                if let latitude = entry.latitude, let longitude = entry.longitude {
                    CoffeeLocationMapView(
                        location: entry.location,
                        coordinate: CLLocationCoordinate2D(latitude: latitude, longitude: longitude),
                        mapPosition: $mapPosition,
                        colorScheme: colorScheme
                    )
                }
            }
            .padding(.vertical)
        }
        .navigationTitle("Coffee Details")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button {
                    showingEdit = true
                } label: {
                    Text("EDIT")
                }
                .dramaticButtonStyle()
            }
        }
        .sheet(isPresented: $showingEdit) {
            CoffeeEntryForm(entryToEdit: entry)
        }
        .onChange(of: showingEdit) { newValue in
            if newValue == false {
                updateMapPosition()
            }
        }
        .onAppear {
            updateMapPosition()
        }
    }
    
    private func updateMapPosition() {
        if let latitude = entry.latitude, let longitude = entry.longitude {
            let coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
            mapPosition = .region(MKCoordinateRegion(
                center: coordinate,
                span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
            ))
        }
    }
}



// MARK: - Preview
#Preview {
    NavigationStack {
        CoffeeEntryDetail(entry: CoffeeEntry(
            coffeeName: "Ethiopian Blend",
            location: "Awesome Coffee Shop",
            dateConsumed: Date(),
            coffeeRating: 5,
            placeRating: 4,
            notes: "Great place with excellent ambiance. The coffee had a subtle fruity note with chocolatey finish."
        ))
    }
    .modelContainer(for: CoffeeEntry.self, inMemory: true)
} 