//
//  LaunchScreen.swift
//  CocoaHeads
//
//  Created by Max Seelemann on 15.05.25.
//

import SwiftUI

struct LaunchScreen: View {
    var body: some View {
        ZStack {
            // Background
            Color(UIColor.systemBackground)
                .ignoresSafeArea()
            
            VStack(spacing: 24) {
                // Coffee cup with liquid and steam
                ZStack {
                    // Cup outline
                    CoffeeCupOutlineShape()
                        .stroke(Color.accentColor, lineWidth: 5)
                        .frame(width: 180, height: 180)
                    
                    // Coffee liquid
                    CoffeeLiquidShape()
                        .fill(Color.accentColor)
                        .frame(width: 180, height: 180)
                    
                    // Steam
                    SteamShape()
                        .stroke(Color.accentColor.opacity(0.7), lineWidth: 3)
                        .frame(width: 180, height: 180)
                }
                .shadow(color: .gray.opacity(0.4), radius: 3, x: 0, y: 2)
                
                // App name
                Text("Coffee Journal")
                    .font(.system(size: 34, weight: .bold, design: .rounded))
                    .foregroundColor(.primary)
            }
        }
    }
}

// Coffee Cup Outline Shape
struct CoffeeCupOutlineShape: Shape {
    func path(in rect: CGRect) -> Path {
        let width = rect.width
        let height = rect.height
        
        var path = Path()
        
        // Cup measurements
        let cupWidth = width * 0.7
        let cupHeight = height * 0.5
        let cupX = (width - cupWidth) / 2
        let cupY = height * 0.2
        let cupRadius = cupWidth * 0.2
        
        // Handle measurements
        let handleWidth = width * 0.15
        let handleHeight = height * 0.3
        let handleX = cupX + cupWidth
        let handleY = cupY + cupHeight * 0.25
        let handleRadius = handleWidth * 0.5
        
        // Saucer measurements
        let saucerWidth = cupWidth * 1.2
        let saucerHeight = height * 0.1
        let saucerX = (width - saucerWidth) / 2
        let saucerY = cupY + cupHeight + height * 0.05
        let saucerRadius = saucerHeight * 0.5
        
        // Draw the cup
        path.addRoundedRect(in: CGRect(x: cupX, y: cupY, width: cupWidth, height: cupHeight), cornerSize: CGSize(width: cupRadius, height: cupRadius))
        
        // Draw the handle
        path.addRoundedRect(in: CGRect(x: handleX, y: handleY, width: handleWidth, height: handleHeight), cornerSize: CGSize(width: handleRadius, height: handleRadius))
        
        // Draw the saucer
        path.addRoundedRect(in: CGRect(x: saucerX, y: saucerY, width: saucerWidth, height: saucerHeight), cornerSize: CGSize(width: saucerRadius, height: saucerRadius))
        
        return path
    }
}

// Coffee Liquid Shape
struct CoffeeLiquidShape: Shape {
    func path(in rect: CGRect) -> Path {
        let width = rect.width
        let height = rect.height
        
        var path = Path()
        
        // Cup measurements
        let cupWidth = width * 0.7
        let cupHeight = height * 0.5
        let cupX = (width - cupWidth) / 2
        let cupY = height * 0.2
        let cupRadius = cupWidth * 0.2
        let padding = width * 0.05
        
        // Coffee level (slightly below top)
        let coffeeHeight = cupHeight * 0.85
        
        // Draw the coffee liquid
        path.addRoundedRect(
            in: CGRect(
                x: cupX + padding,
                y: cupY + padding,
                width: cupWidth - (padding * 2),
                height: coffeeHeight - padding
            ),
            cornerSize: CGSize(width: cupRadius - padding, height: cupRadius - padding)
        )
        
        return path
    }
}

// Steam Shape
struct SteamShape: Shape {
    func path(in rect: CGRect) -> Path {
        let width = rect.width
        let height = rect.height
        
        var path = Path()
        
        // Cup measurements for reference
        let cupWidth = width * 0.7
        let cupX = (width - cupWidth) / 2
        let cupY = height * 0.2
        
        // Steam starting positions
        let steamBaseY = cupY - 5
        
        // First steam curve
        let steam1X = cupX + (cupWidth * 0.25)
        path.move(to: CGPoint(x: steam1X, y: steamBaseY))
        path.addCurve(
            to: CGPoint(x: steam1X - width * 0.05, y: steamBaseY - height * 0.2),
            control1: CGPoint(x: steam1X + width * 0.05, y: steamBaseY - height * 0.08),
            control2: CGPoint(x: steam1X - width * 0.1, y: steamBaseY - height * 0.12)
        )
        
        // Second steam curve
        let steam2X = cupX + (cupWidth * 0.5)
        path.move(to: CGPoint(x: steam2X, y: steamBaseY))
        path.addCurve(
            to: CGPoint(x: steam2X + width * 0.05, y: steamBaseY - height * 0.22),
            control1: CGPoint(x: steam2X - width * 0.05, y: steamBaseY - height * 0.1),
            control2: CGPoint(x: steam2X + width * 0.1, y: steamBaseY - height * 0.15)
        )
        
        // Third steam curve
        let steam3X = cupX + (cupWidth * 0.75)
        path.move(to: CGPoint(x: steam3X, y: steamBaseY))
        path.addCurve(
            to: CGPoint(x: steam3X - width * 0.02, y: steamBaseY - height * 0.18),
            control1: CGPoint(x: steam3X + width * 0.08, y: steamBaseY - height * 0.08),
            control2: CGPoint(x: steam3X - width * 0.1, y: steamBaseY - height * 0.12)
        )
        
        return path
    }
}

#Preview {
    LaunchScreen()
} 