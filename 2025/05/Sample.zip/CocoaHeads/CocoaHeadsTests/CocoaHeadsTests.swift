//
//  CocoaHeadsTests.swift
//  CocoaHeadsTests
//
//  Created by Max Seelemann on 15.05.25.
//

import Testing
@testable import CocoaHeads

struct CocoaHeadsTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
