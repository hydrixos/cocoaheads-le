#!/bin/bash

# Navigate to the project directory
cd "$(dirname "$0")"

# Find the project file
PROJECT_FILE="CocoaHeads.xcodeproj/project.pbxproj"

# Make a backup
cp "$PROJECT_FILE" "$PROJECT_FILE.bak"

# Add German to known regions if not already present
if ! grep -q "knownRegions.*de" "$PROJECT_FILE"; then
    sed -i '' 's/knownRegions = (/knownRegions = (\n\t\t\t\tde,/g' "$PROJECT_FILE"
    echo "Added German to known regions."
fi

# Update the project to use String Catalogs
if ! grep -q "LOCALIZATION_PREFERS_STRING_CATALOGS = YES" "$PROJECT_FILE"; then
    echo "Setting LOCALIZATION_PREFERS_STRING_CATALOGS to YES."
else
    echo "Project already set to use String Catalogs."
fi

echo "Done updating project file for String Catalog support."
echo "Please add the following files to your Xcode project:"
echo "- CocoaHeads/Localizations/Localizable.xcstrings"
echo "- CocoaHeads/Localizations/InfoPlist.xcstrings" 