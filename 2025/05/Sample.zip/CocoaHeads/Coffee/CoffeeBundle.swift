//
//  CoffeeBundle.swift
//  Coffee
//
//  Created by Max Seelemann on 15.05.25.
//

import WidgetKit
import SwiftUI

@main
struct CoffeeBundle: WidgetBundle {
    var body: some Widget {
        Coffee()
    }
}
