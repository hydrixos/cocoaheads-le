//
//  AppIntent.swift
//  Coffee
//
//  Created by Max Seelemann on 15.05.25.
//

import WidgetKit
import AppIntents

struct CoffeeWidgetConfigurationIntent: WidgetConfigurationIntent {
    static var title: LocalizedStringResource { "Coffee Journal Widget" }
    static var description: IntentDescription { "Displays your recent coffee entries." }

    @Parameter(title: "Display Mode", default: .latest)
    var displayMode: DisplayMode
    
    @Parameter(title: "Show Ratings", default: true)
    var showRatings: Bool
}

enum DisplayMode: String, AppEnum {
    case latest
    case highest
    
    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Display Mode"
    static var caseDisplayRepresentations: [DisplayMode: DisplayRepresentation] = [
        .latest: "Latest Entry",
        .highest: "Highest Rated"
    ]
}
