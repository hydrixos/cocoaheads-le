//
//  Coffee.swift
//  Coffee
//
//  Created by Max Seelemann on 15.05.25.
//

import WidgetKit
import SwiftUI
import SwiftData
import CoreLocation

struct Provider: AppIntentTimelineProvider {
    func placeholder(in context: Context) -> SimpleEntry {
        let sample = CoffeeEntry(
            coffeeName: "Cappuccino",
            location: "Café Central",
            dateConsumed: Date(),
            coffeeRating: 4,
            placeRating: 5,
            notes: "Delicious!"
        )
        return SimpleEntry(date: Date(), configuration: CoffeeWidgetConfigurationIntent(), coffeeEntry: sample)
    }

    func snapshot(for configuration: CoffeeWidgetConfigurationIntent, in context: Context) async -> SimpleEntry {
        let sample = CoffeeEntry(
            coffeeName: "Cappuccino",
            location: "Café Central",
            dateConsumed: Date(),
            coffeeRating: 4,
            placeRating: 5,
            notes: "Delicious!"
        )
        return SimpleEntry(date: Date(), configuration: configuration, coffeeEntry: sample)
    }
    
    func timeline(for configuration: CoffeeWidgetConfigurationIntent, in context: Context) async -> Timeline<SimpleEntry> {
        // Create a sample entry as fallback
        let sampleEntry = CoffeeEntry(
            coffeeName: "Cappuccino",
            location: "Café Central",
            dateConsumed: Date(),
            coffeeRating: 4,
            placeRating: 5,
            notes: "Delicious!"
        )
        
        var coffeeEntry = sampleEntry
        
        // Access the shared SwiftData store
        do {
            // Set up the model container with the shared app group
            let modelConfig = ModelConfiguration(groupContainer: .identifier("group.com.cocoaheads.journal"))
            let schema = Schema([CoffeeEntry.self])
            let container = try ModelContainer(for: schema, configurations: [modelConfig])
            let context = ModelContext(container)
            
            // Query for entries based on the display mode
            switch configuration.displayMode {
            case .latest:
                var fetchDescriptor = FetchDescriptor<CoffeeEntry>(sortBy: [SortDescriptor(\.dateConsumed, order: .reverse)])
                fetchDescriptor.fetchLimit = 1
                
                let results = try context.fetch(fetchDescriptor)
                if let entry = results.first {
                    coffeeEntry = entry
                }
                
            case .highest:
                var fetchDescriptor = FetchDescriptor<CoffeeEntry>(sortBy: [SortDescriptor(\.coffeeRating, order: .reverse)])
                fetchDescriptor.fetchLimit = 1
                
                let results = try context.fetch(fetchDescriptor)
                if let entry = results.first {
                    coffeeEntry = entry
                }
            }
        } catch {
            print("Error fetching coffee entries: \(error)")
            // We'll use the sample entry if there's an error
        }
        
        let entry = SimpleEntry(
            date: Date(),
            configuration: configuration,
            coffeeEntry: coffeeEntry
        )
        
        // Update every 15 minutes or when the widget is reloaded
        let refreshDate = Calendar.current.date(byAdding: .minute, value: 15, to: Date()) ?? Date()
        return Timeline(entries: [entry], policy: .after(refreshDate))
    }
}

struct SimpleEntry: TimelineEntry {
    let date: Date
    let configuration: CoffeeWidgetConfigurationIntent
    let coffeeEntry: CoffeeEntry
}

struct CoffeeWidgetEntryView: View {
    var entry: Provider.Entry
    @Environment(\.widgetFamily) private var widgetFamily
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(entry.coffeeEntry.coffeeName)
                    .font(.headline)
                    .lineLimit(1)
                
                Spacer()
                
                if entry.configuration.displayMode == .highest {
                    Image(systemName: "trophy.fill")
                        .font(.caption)
                        .foregroundStyle(.yellow)
                }
            }
            
            Text(entry.coffeeEntry.location)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            
            if entry.configuration.showRatings {
                HStack {
                    Label("Coffee: \(entry.coffeeEntry.coffeeRating)/5", systemImage: "cup.and.saucer.fill")
                        .font(.caption)
                    
                    if widgetFamily != .systemSmall {
                        Spacer()
                        Label("Place: \(entry.coffeeEntry.placeRating)/5", systemImage: "mappin.circle.fill")
                            .font(.caption)
                    }
                }
                .padding(.top, 2)
            }
            
            Spacer()
            
            HStack {
                Image(systemName: "calendar")
                    .font(.caption2)
                Text(entry.coffeeEntry.dateConsumed, style: .date)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                
                Spacer()
            }
        }
        .padding()
        .containerBackground(.quaternary, for: .widget)
    }
}

struct Coffee: Widget {
    let kind: String = "Coffee"

    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: kind, intent: CoffeeWidgetConfigurationIntent.self, provider: Provider()) { entry in
            CoffeeWidgetEntryView(entry: entry)
        }
    }
}

#Preview(as: .systemSmall) {
    Coffee()
} timeline: {
    let sample1 = CoffeeEntry(
        coffeeName: "Cappuccino",
        location: "Café Central",
        dateConsumed: Date(),
        coffeeRating: 4, 
        placeRating: 5,
        notes: "Delicious!"
    )
    
    let sample2 = CoffeeEntry(
        coffeeName: "Espresso",
        location: "Bean There",
        dateConsumed: Date().addingTimeInterval(-3600),
        coffeeRating: 5,
        placeRating: 3,
        notes: "Strong!"
    )
    
    SimpleEntry(date: .now, configuration: CoffeeWidgetConfigurationIntent(), coffeeEntry: sample1)
    SimpleEntry(date: .now, configuration: {
        let config = CoffeeWidgetConfigurationIntent()
        config.showRatings = false
        return config
    }(), coffeeEntry: sample2)
}

#Preview(as: .systemMedium) {
    Coffee()
} timeline: {
    let sample = CoffeeEntry(
        coffeeName: "Latte",
        location: "Morning Brew",
        dateConsumed: Date().addingTimeInterval(-7200),
        coffeeRating: 3,
        placeRating: 4,
        notes: "Creamy!"
    )
    
    SimpleEntry(date: .now, configuration: CoffeeWidgetConfigurationIntent(), coffeeEntry: sample)
}
