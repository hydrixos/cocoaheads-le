/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

 // react-native run-ios

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  TextInput,
  View,
  NavigatorIOS,
  FlatList
} from 'react-native';

export default class ReactNotes extends Component {

  _onPressItem = (noteId) => {
  	this.refs.nav.push({
  		component: NoteDetail,
  		title: 'Detail',
  		passProps: { noteId: noteId },
  	});
  }

  render() {
    return (
      <NavigatorIOS
        ref='nav'
        initialRoute={{
          component: NotesList,
          title: 'Notes',
          passProps: { onPressItem: this._onPressItem },
        }}
        style={{flex: 1}}
        translucent={false}
      />
    );
  }
}

class NotesList extends Component {

  render() {
  	return <FlatList
        data={notesData}
        renderItem={({item}) =>
          <Text
          	onPress={() => this.props.onPressItem(item.key)} 
            style={[styles.noteRow, styles.container]}>{item.key}</Text>}
      	  />
  }

}

class NoteDetail extends Component {

  constructor(props) {
  	super(props);
  	var note = notesData.find((element) => element.key === this.props.noteId)
  	this.state = {text: note.key};
  }

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.noteHeader}>
          {this.state.text == '' ? 'New note' : this.state.text.substring(0,10)}
        </Text>
        <TextInput
          style={{height: 40}}
          placeholder="New note goes here…"
          onChangeText={(text) => this.setState({text})}
        />
      </View>
    )
  }

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    margin: 16,
  },
  noteHeader: {
    fontSize: 20,
    textAlign: 'left',
  },
  noteRow: {
  	fontSize: 39,
  	padding: 8,
  }
});

const notesData = [
  {key: 'Note 1'},
  {key: 'Note 2'},
  {key: 'Note 3'},
  {key: 'Note 4'},
  {key: 'Note 5'},
  ]

AppRegistry.registerComponent('ReactNotes', () => ReactNotes);
