//
//  OverviewInterfaceController.h
//  WatchKit Sample WatchKit Extension
//
//  Created by Friedrich Gräter on 02/12/14.
//  Copyright (c) 2014 The Soulmen GbR. All rights reserved.
//

/*!
 @abstract An interface controller providing a day overview.
 */
@interface OverviewInterfaceController : WKInterfaceController

@end
