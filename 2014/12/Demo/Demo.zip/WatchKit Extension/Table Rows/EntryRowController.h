//
//  EntryRowController.h
//  WatchKit Sample
//
//  Created by Friedrich Gräter on 02/12/14.
//  Copyright (c) 2014 The Soulmen GbR. All rights reserved.
//

@class AdventCalendarEntry;

@interface EntryRowController : NSObject

@property(nonatomic) AdventCalendarEntry *calendarEntry;

@end
