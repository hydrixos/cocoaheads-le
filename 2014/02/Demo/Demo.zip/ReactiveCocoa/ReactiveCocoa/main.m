//
//  main.m
//  ReactiveCocoa
//
//  Created by Friedrich Gräter on 01.02.14.
//  Copyright (c) 2014 Friedrich Gräter. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RCAppDelegate.h"

int main(int argc, char * argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([RCAppDelegate class]));
	}
}
