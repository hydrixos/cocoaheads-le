//
//  TRMailDetailsViewController.h
//  AutomationDemo
//
//  Created by trispo on 07/01/14.
//  Copyright (c) 2014 trispo. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TRMailModel;

@interface TRMailDetailsViewController : UIViewController

@property (nonatomic, strong) TRMailModel *mail;

@end
