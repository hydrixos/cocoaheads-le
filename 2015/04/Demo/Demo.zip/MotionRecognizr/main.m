//
//  main.m
//  Squats
//
//  Created by Götz Fabian on 13/04/15.
//  Copyright (c) 2015 The Soulmen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
