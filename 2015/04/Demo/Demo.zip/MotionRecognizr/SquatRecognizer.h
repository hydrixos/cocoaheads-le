//
//  SquatRecognizer.h
//  Squats
//
//  Created by Götz Fabian on 14/04/15.
//  Copyright (c) 2015 The Soulmen. All rights reserved.
//

#import "MotionRecognizer.h"

@interface SquatRecognizer : MotionRecognizer

@end
