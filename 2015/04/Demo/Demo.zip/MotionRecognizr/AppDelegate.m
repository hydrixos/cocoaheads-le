//
//  AppDelegate.m
//  Squats
//
//  Created by Götz Fabian on 13/04/15.
//  Copyright (c) 2015 The Soulmen. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

@end
