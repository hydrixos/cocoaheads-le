//
//  AppDelegate.h
//  Squats
//
//  Created by Götz Fabian on 13/04/15.
//  Copyright (c) 2015 The Soulmen. All rights reserved.
//


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

